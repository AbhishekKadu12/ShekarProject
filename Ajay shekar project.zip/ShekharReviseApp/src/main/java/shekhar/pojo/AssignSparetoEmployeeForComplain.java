/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shekhar.pojo;

/**
 *
 * @author Horten
 */
public class AssignSparetoEmployeeForComplain {
  private String ename;  
  private Integer cid;
  private String sparetype;

    /**
     * @return the ename
     */
    public String getEname() {
        return ename;
    }

    /**
     * @param ename the ename to set
     */
    public void setEname(String ename) {
        this.ename = ename;
    }

    /**
     * @return the cid
     */
    public Integer getCid() {
        return cid;
    }

    /**
     * @param cid the cid to set
     */
    public void setCid(Integer cid) {
        this.cid = cid;
    }

    /**
     * @return the sparetype
     */
    public String getSparetype() {
        return sparetype;
    }

    /**
     * @param sparetype the sparetype to set
     */
    public void setSparetype(String sparetype) {
        this.sparetype = sparetype;
    }
  
}
