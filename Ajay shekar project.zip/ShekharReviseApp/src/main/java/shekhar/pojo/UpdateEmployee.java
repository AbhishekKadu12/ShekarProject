/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shekhar.pojo;

/**
 *
 * @author Horten
 */
public class UpdateEmployee {
    private String EmployeeName;
    private String EmployeeEmail;
    private String EmployeeAddress;
    private String EmployeeContact;
    private String EmployeeJoiningDate;
    private String EmployeeDesignation;

    /**
     * @return the EmployeeName
     */
    public String getEmployeeName() {
        return EmployeeName;
    }

    /**
     * @param EmployeeName the EmployeeName to set
     */
    public void setEmployeeName(String EmployeeName) {
        this.EmployeeName = EmployeeName;
    }

    /**
     * @return the EmployeeEmail
     */
    public String getEmployeeEmail() {
        return EmployeeEmail;
    }

    /**
     * @param EmployeeEmail the EmployeeEmail to set
     */
    public void setEmployeeEmail(String EmployeeEmail) {
        this.EmployeeEmail = EmployeeEmail;
    }

    /**
     * @return the EmployeeAddress
     */
    public String getEmployeeAddress() {
        return EmployeeAddress;
    }

    /**
     * @param EmployeeAddress the EmployeeAddress to set
     */
    public void setEmployeeAddress(String EmployeeAddress) {
        this.EmployeeAddress = EmployeeAddress;
    }

    /**
     * @return the EmployeeContact
     */
    public String getEmployeeContact() {
        return EmployeeContact;
    }

    /**
     * @param EmployeeContact the EmployeeContact to set
     */
    public void setEmployeeContact(String EmployeeContact) {
        this.EmployeeContact = EmployeeContact;
    }

    /**
     * @return the EmployeeJoiningDate
     */
    public String getEmployeeJoiningDate() {
        return EmployeeJoiningDate;
    }

    /**
     * @param EmployeeJoiningDate the EmployeeJoiningDate to set
     */
    public void setEmployeeJoiningDate(String EmployeeJoiningDate) {
        this.EmployeeJoiningDate = EmployeeJoiningDate;
    }

    /**
     * @return the EmployeeDesignation
     */
    public String getEmployeeDesignation() {
        return EmployeeDesignation;
    }

    /**
     * @param EmployeeDesignation the EmployeeDesignation to set
     */
    public void setEmployeeDesignation(String EmployeeDesignation) {
        this.EmployeeDesignation = EmployeeDesignation;
    }
}
