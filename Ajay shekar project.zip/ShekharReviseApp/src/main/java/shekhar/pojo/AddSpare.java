/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shekhar.pojo;

/**
 *
 * @author Horten
 */
public class AddSpare {
    private String sname;
    private String scost;
    private String sDesc;
    private String sComp;
    private String WDate;
    private String Type;
    private int spareid;
    private int pid;
    private String complainid;
    private String empid;
    private String Status;
    private int sparecost;
    private String date;
    

    /**
     * @return the sname
     */
    public String getSname() {
        return sname;
    }

    /**
     * @param sname the sname to set
     */
    public void setSname(String sname) {
        this.sname = sname;
    }

    /**
     * @return the scost
     */
    public String getScost() {
        return scost;
    }

    /**
     * @param scost the scost to set
     */
    public void setScost(String scost) {
        this.scost = scost;
    }

    /**
     * @return the sDesc
     */
    public String getsDesc() {
        return sDesc;
    }

    /**
     * @param sDesc the sDesc to set
     */
    public void setsDesc(String sDesc) {
        this.sDesc = sDesc;
    }

    /**
     * @return the sComp
     */
    public String getsComp() {
        return sComp;
    }

    /**
     * @param sComp the sComp to set
     */
    public void setsComp(String sComp) {
        this.sComp = sComp;
    }

    /**
     * @return the WDate
     */
    public String getWDate() {
        return WDate;
    }

    /**
     * @param WDate the WDate to set
     */
    public void setWDate(String WDate) {
        this.WDate = WDate;
    }

    /**
     * @return the Type
     */
    public String getType() {
        return Type;
    }

    /**
     * @param Type the Type to set
     */
    public void setType(String Type) {
        this.Type = Type;
    }

    /**
     * @return the spareid
     */
    public int getSpareid() {
        return spareid;
    }

    /**
     * @param spareid the spareid to set
     */
    public void setSpareid(int spareid) {
        this.spareid = spareid;
    }

    /**
     * @return the pid
     */
    public int getPid() {
        return pid;
    }

    /**
     * @param pid the pid to set
     */
    public void setPid(int pid) {
        this.pid = pid;
    }

    /**
     * @return the complainid
     */
    public String getComplainid() {
        return complainid;
    }

    /**
     * @param complainid the complainid to set
     */
    public void setComplainid(String complainid) {
        this.complainid = complainid;
    }

    /**
     * @return the empid
     */
    public String getEmpid() {
        return empid;
    }

    /**
     * @param empid the empid to set
     */
    public void setEmpid(String empid) {
        this.empid = empid;
    }

    /**
     * @return the Status
     */
    public String getStatus() {
        return Status;
    }

    /**
     * @param Status the Status to set
     */
    public void setStatus(String Status) {
        this.Status = Status;
    }

    /**
     * @return the sparecost
     */
    public int getSparecost() {
        return sparecost;
    }

    /**
     * @param sparecost the sparecost to set
     */
    public void setSparecost(int sparecost) {
        this.sparecost = sparecost;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }
}
