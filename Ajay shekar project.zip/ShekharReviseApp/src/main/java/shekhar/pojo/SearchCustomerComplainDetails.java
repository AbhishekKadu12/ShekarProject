/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shekhar.pojo;

/**
 *
 * @author Naresh
 */
public class SearchCustomerComplainDetails {
    private int pid;
    private String Pname;
    private int customerid;
    private String custname;
    private String adderss;
    private String contact;
    private String email;
    private String Wdate;

    /**
     * @return the pid
     */
    public int getPid() {
        return pid;
    }

    /**
     * @param pid the pid to set
     */
    public void setPid(int pid) {
        this.pid = pid;
    }

    /**
     * @return the Pname
     */
    public String getPname() {
        return Pname;
    }

    /**
     * @param Pname the Pname to set
     */
    public void setPname(String Pname) {
        this.Pname = Pname;
    }

    /**
     * @return the customerid
     */
    public int getCustomerid() {
        return customerid;
    }

    /**
     * @param customerid the customerid to set
     */
    public void setCustomerid(int customerid) {
        this.customerid = customerid;
    }

    /**
     * @return the custname
     */
    public String getCustname() {
        return custname;
    }

    /**
     * @param custname the custname to set
     */
    public void setCustname(String custname) {
        this.custname = custname;
    }

    /**
     * @return the adderss
     */
    public String getAdderss() {
        return adderss;
    }

    /**
     * @param adderss the adderss to set
     */
    public void setAdderss(String adderss) {
        this.adderss = adderss;
    }

    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     */
    public void setContact(String contact) {
        this.contact = contact;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the Wdate
     */
    public String getWdate() {
        return Wdate;
    }

    /**
     * @param Wdate the Wdate to set
     */
    public void setWdate(String Wdate) {
        this.Wdate = Wdate;
    }
}
