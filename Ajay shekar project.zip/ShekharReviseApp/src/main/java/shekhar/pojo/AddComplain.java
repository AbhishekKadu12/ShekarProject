/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shekhar.pojo;

/**
 *
 * @author Horten
 */
public class AddComplain {

    private String ComplainId;
    private String ComplainDescription;
    private String ComplainDate;
    private String ComplainTime;
    private String ComplainStatus;
    private int CustomerId;
    private String complainbill;
    private String empid;
    private int spareid;
    private String complainid;
    private int pid;

    private String Status;
    private int spaercost;
    private String date;

    
    private String Vtype;
    private String Sdate;
    private String wDetails;
    private String IcrNO;
    private String Fdate;
    private String Tdate;
    private String ContractNo;
      private String qty;
        private String rate;
    /**
     * @return the ComplainId
     */
    public String getComplainId() {
        return ComplainId;
    }

    /**
     * @param ComplainId the ComplainId to set
     */
    public void setComplainId(String ComplainId) {
        this.ComplainId = ComplainId;
    }

    /**
     * @return the ComplainDescription
     */
    public String getComplainDescription() {
        return ComplainDescription;
    }

    /**
     * @param ComplainDescription the ComplainDescription to set
     */
    public void setComplainDescription(String ComplainDescription) {
        this.ComplainDescription = ComplainDescription;
    }

    /**
     * @return the ComplainDate
     */
    public String getComplainDate() {
        return ComplainDate;
    }

    /**
     * @param ComplainDate the ComplainDate to set
     */
    public void setComplainDate(String ComplainDate) {
        this.ComplainDate = ComplainDate;
    }

    /**
     * @return the ComplainTime
     */
    public String getComplainTime() {
        return ComplainTime;
    }

    /**
     * @param ComplainTime the ComplainTime to set
     */
    public void setComplainTime(String ComplainTime) {
        this.ComplainTime = ComplainTime;
    }

    /**
     * @return the ComplainStatus
     */
    public String getComplainStatus() {
        return ComplainStatus;
    }

    /**
     * @param ComplainStatus the ComplainStatus to set
     */
    public void setComplainStatus(String ComplainStatus) {
        this.ComplainStatus = ComplainStatus;
    }

    /**
     * @return the CustomerId
     */
    public int getCustomerId() {
        return CustomerId;
    }

    /**
     * @param CustomerId the CustomerId to set
     */
    public void setCustomerId(int CustomerId) {
        this.CustomerId = CustomerId;
    }

    /**
     * @return the complainbill
     */
    /**
     * @return the empid
     */
    public String getEmpid() {
        return empid;
    }

    /**
     * @param empid the empid to set
     */
    public void setEmpid(String empid) {
        this.empid = empid;
    }

    /**
     * @return the spareid
     */
    public int getSpareid() {
        return spareid;
    }

    /**
     * @param spareid the spareid to set
     */
    public void setSpareid(int spareid) {
        this.spareid = spareid;
    }

    /**
     * @return the complainid
     */
    public String getComplainid() {
        return complainid;
    }

    /**
     * @param complainid the complainid to set
     */
    public void setComplainid(String complainid) {
        this.complainid = complainid;
    }

    /**
     * @return the pid
     */
    public int getPid() {
        return pid;
    }

    /**
     * @param pid the pid to set
     */
    public void setPid(int pid) {
        this.pid = pid;
    }

    /**
     * @return the Status
     */
    public String getStatus() {
        return Status;
    }

    /**
     * @param Status the Status to set
     */
    public void setStatus(String Status) {
        this.Status = Status;
    }

    /**
     * @return the spaercost
     */
    public int getSpaercost() {
        return spaercost;
    }

    /**
     * @param spaercost the spaercost to set
     */
    public void setSpaercost(int spaercost) {
        this.spaercost = spaercost;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the complainbill
     */
    public String getComplainbill() {
        return complainbill;
    }

    /**
     * @param complainbill the complainbill to set
     */
    public void setComplainbill(String complainbill) {
        this.complainbill = complainbill;
    }

    /**
     * @return the Vtype
     */
    public String getVtype() {
        return Vtype;
    }

    /**
     * @param Vtype the Vtype to set
     */
    public void setVtype(String Vtype) {
        this.Vtype = Vtype;
    }

    /**
     * @return the Sdate
     */
    public String getSdate() {
        return Sdate;
    }

    /**
     * @param Sdate the Sdate to set
     */
    public void setSdate(String Sdate) {
        this.Sdate = Sdate;
    }

    /**
     * @return the wDetails
     */
    public String getwDetails() {
        return wDetails;
    }

    /**
     * @param wDetails the wDetails to set
     */
    public void setwDetails(String wDetails) {
        this.wDetails = wDetails;
    }

    /**
     * @return the IcrNO
     */
    public String getIcrNO() {
        return IcrNO;
    }

    /**
     * @param IcrNO the IcrNO to set
     */
    public void setIcrNO(String IcrNO) {
        this.IcrNO = IcrNO;
    }

    /**
     * @return the Fdate
     */
    public String getFdate() {
        return Fdate;
    }

    /**
     * @param Fdate the Fdate to set
     */
    public void setFdate(String Fdate) {
        this.Fdate = Fdate;
    }

    /**
     * @return the Tdate
     */
    public String getTdate() {
        return Tdate;
    }

    /**
     * @param Tdate the Tdate to set
     */
    public void setTdate(String Tdate) {
        this.Tdate = Tdate;
    }

    /**
     * @return the ContractNo
     */
    public String getContractNo() {
        return ContractNo;
    }

    /**
     * @param ContractNo the ContractNo to set
     */
    public void setContractNo(String ContractNo) {
        this.ContractNo = ContractNo;
    }

    /**
     * @return the qty
     */
    public String getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(String qty) {
        this.qty = qty;
    }

    /**
     * @return the rate
     */
    public String getRate() {
        return rate;
    }

    /**
     * @param rate the rate to set
     */
    public void setRate(String rate) {
        this.rate = rate;
    }

    /**
     * @return the CustomerId
     */
    /**
     * @return the CustomerId
     */
    /**
     * @return the CustomerId
     */
    /**
     * @return the CustomerId
     */
}
