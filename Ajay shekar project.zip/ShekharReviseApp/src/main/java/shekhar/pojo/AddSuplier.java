/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shekhar.pojo;

/**
 *
 * @author Sunny
 */
public class AddSuplier {
  private String supliername;
  private String suplieremail;
  private String supliercontact;
  private String suplieraddress;
  private String supliercompany;

    /**
     * @return the supliername
     */
    public String getSupliername() {
        return supliername;
    }

    /**
     * @param supliername the supliername to set
     */
    public void setSupliername(String supliername) {
        this.supliername = supliername;
    }

    /**
     * @return the suplieremail
     */
    public String getSuplieremail() {
        return suplieremail;
    }

    /**
     * @param suplieremail the suplieremail to set
     */
    public void setSuplieremail(String suplieremail) {
        this.suplieremail = suplieremail;
    }

    /**
     * @return the supliercontact
     */
    public String getSupliercontact() {
        return supliercontact;
    }

    /**
     * @param supliercontact the supliercontact to set
     */
    public void setSupliercontact(String supliercontact) {
        this.supliercontact = supliercontact;
    }

    /**
     * @return the suplieraddress
     */
    public String getSuplieraddress() {
        return suplieraddress;
    }

    /**
     * @param suplieraddress the suplieraddress to set
     */
    public void setSuplieraddress(String suplieraddress) {
        this.suplieraddress = suplieraddress;
    }

    /**
     * @return the supliercompany
     */
    public String getSupliercompany() {
        return supliercompany;
    }

    /**
     * @param supliercompany the supliercompany to set
     */
    public void setSupliercompany(String supliercompany) {
        this.supliercompany = supliercompany;
    }
}
