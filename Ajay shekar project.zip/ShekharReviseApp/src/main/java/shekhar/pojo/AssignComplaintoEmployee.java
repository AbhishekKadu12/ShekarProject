/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shekhar.pojo;

/**
 *
 * @author Horten
 */
public class AssignComplaintoEmployee {

    private int complainid;
    private int custid;
    private int empid;
    private String complaindate;
    private String complaintime;
    private String complaintype;
    private String datetosend;
    private String reason;
    private int totleCharge;
    private int PaindingAmount;
    private int Rmaining;

    /**
     * @return the complainid
     */
    public int getComplainid() {
        return complainid;
    }

    /**
     * @param complainid the complainid to set
     */
    public void setComplainid(int complainid) {
        this.complainid = complainid;
    }

    /**
     * @return the custid
     */
    public int getCustid() {
        return custid;
    }

    /**
     * @param custid the custid to set
     */
    public void setCustid(int custid) {
        this.custid = custid;
    }

    /**
     * @return the empid
     */
    public int getEmpid() {
        return empid;
    }

    /**
     * @param empid the empid to set
     */
    public void setEmpid(int empid) {
        this.empid = empid;
    }

    /**
     * @return the complaindate
     */
    public String getComplaindate() {
        return complaindate;
    }

    /**
     * @param complaindate the complaindate to set
     */
    public void setComplaindate(String complaindate) {
        this.complaindate = complaindate;
    }

    /**
     * @return the complaintime
     */
    public String getComplaintime() {
        return complaintime;
    }

    /**
     * @param complaintime the complaintime to set
     */
    public void setComplaintime(String complaintime) {
        this.complaintime = complaintime;
    }

    /**
     * @return the complaintype
     */
    public String getComplaintype() {
        return complaintype;
    }

    /**
     * @param complaintype the complaintype to set
     */
    public void setComplaintype(String complaintype) {
        this.complaintype = complaintype;
    }

    /**
     * @return the datetosend
     */
    public String getDatetosend() {
        return datetosend;
    }

    /**
     * @param datetosend the datetosend to set
     */
    public void setDatetosend(String datetosend) {
        this.datetosend = datetosend;
    }

    /**
     * @return the reason
     */
    public String getReason() {
        return reason;
    }

    /**
     * @param reason the reason to set
     */
    public void setReason(String reason) {
        this.reason = reason;
    }

    /**
     * @return the totleCharge
     */
    public int getTotleCharge() {
        return totleCharge;
    }

    /**
     * @param totleCharge the totleCharge to set
     */
    public void setTotleCharge(int totleCharge) {
        this.totleCharge = totleCharge;
    }

    /**
     * @return the PaindingAmount
     */
    public int getPaindingAmount() {
        return PaindingAmount;
    }

    /**
     * @param PaindingAmount the PaindingAmount to set
     */
    public void setPaindingAmount(int PaindingAmount) {
        this.PaindingAmount = PaindingAmount;
    }

    /**
     * @return the Rmaining
     */
    public int getRmaining() {
        return Rmaining;
    }

    /**
     * @param Rmaining the Rmaining to set
     */
    public void setRmaining(int Rmaining) {
        this.Rmaining = Rmaining;
    }

    
    
}
