/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shekhar.pojo;

/**
 *
 * @author Horten
 */
public class RegisterComplainFromOffice {
    private String ComplainDesc;
    private String date;
    private String time;
    private String ststus;
    private Integer id;
    private String name;
    private String contact;

    /**
     * @return the ComplainDesc
     */
    public String getComplainDesc() {
        return ComplainDesc;
    }

    /**
     * @param ComplainDesc the ComplainDesc to set
     */
    public void setComplainDesc(String ComplainDesc) {
        this.ComplainDesc = ComplainDesc;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * @return the ststus
     */
    public String getStstus() {
        return ststus;
    }

    /**
     * @param ststus the ststus to set
     */
    public void setStstus(String ststus) {
        this.ststus = ststus;
    }

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     */
    public void setContact(String contact) {
        this.contact = contact;
    }

}
