/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shekhar.pojo;

/**
 *
 * @author Horten
 */
public class ViewSolveComplain {
    private Integer cid;
    private String cname;
    private String date;
    private String Tamount;
    private String Pamount;
    private String Ramount;
    private String SpareDesc;

    /**
     * @return the cid
     */
    public Integer getCid() {
        return cid;
    }

    /**
     * @param cid the cid to set
     */
    public void setCid(Integer cid) {
        this.cid = cid;
    }

    /**
     * @return the cname
     */
    public String getCname() {
        return cname;
    }

    /**
     * @param cname the cname to set
     */
    public void setCname(String cname) {
        this.cname = cname;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the Tamount
     */
    public String getTamount() {
        return Tamount;
    }

    /**
     * @param Tamount the Tamount to set
     */
    public void setTamount(String Tamount) {
        this.Tamount = Tamount;
    }

    /**
     * @return the Pamount
     */
    public String getPamount() {
        return Pamount;
    }

    /**
     * @param Pamount the Pamount to set
     */
    public void setPamount(String Pamount) {
        this.Pamount = Pamount;
    }

    /**
     * @return the Ramount
     */
    public String getRamount() {
        return Ramount;
    }

    /**
     * @param Ramount the Ramount to set
     */
    public void setRamount(String Ramount) {
        this.Ramount = Ramount;
    }

    /**
     * @return the SpareDesc
     */
    public String getSpareDesc() {
        return SpareDesc;
    }

    /**
     * @param SpareDesc the SpareDesc to set
     */
    public void setSpareDesc(String SpareDesc) {
        this.SpareDesc = SpareDesc;
    }
}
