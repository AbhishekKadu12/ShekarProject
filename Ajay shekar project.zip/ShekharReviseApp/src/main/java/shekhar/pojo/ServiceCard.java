/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shekhar.pojo;

/**
 *
 * @author Naresh
 */
public class ServiceCard {
    private String complainid;
    private String Vtype;
    private String Sdate;
    private String wDetails;
    private String IcrNO;
    private String Fdate;
    private String Tdate;
    private String ContractNo;

    /**
     * @return the complainid
     */
    public String getComplainid() {
        return complainid;
    }

    /**
     * @param complainid the complainid to set
     */
    public void setComplainid(String complainid) {
        this.complainid = complainid;
    }

    /**
     * @return the Vtype
     */
    public String getVtype() {
        return Vtype;
    }

    /**
     * @param Vtype the Vtype to set
     */
    public void setVtype(String Vtype) {
        this.Vtype = Vtype;
    }

    /**
     * @return the Sdate
     */
    public String getSdate() {
        return Sdate;
    }

    /**
     * @param Sdate the Sdate to set
     */
    public void setSdate(String Sdate) {
        this.Sdate = Sdate;
    }

    /**
     * @return the wDetails
     */
    public String getwDetails() {
        return wDetails;
    }

    /**
     * @param wDetails the wDetails to set
     */
    public void setwDetails(String wDetails) {
        this.wDetails = wDetails;
    }

    /**
     * @return the IcrNO
     */
    public String getIcrNO() {
        return IcrNO;
    }

    /**
     * @param IcrNO the IcrNO to set
     */
    public void setIcrNO(String IcrNO) {
        this.IcrNO = IcrNO;
    }

    /**
     * @return the Fdate
     */
    public String getFdate() {
        return Fdate;
    }

    /**
     * @param Fdate the Fdate to set
     */
    public void setFdate(String Fdate) {
        this.Fdate = Fdate;
    }

    /**
     * @return the Tdate
     */
    public String getTdate() {
        return Tdate;
    }

    /**
     * @param Tdate the Tdate to set
     */
    public void setTdate(String Tdate) {
        this.Tdate = Tdate;
    }

    /**
     * @return the ContractNo
     */
    public String getContractNo() {
        return ContractNo;
    }

    /**
     * @param ContractNo the ContractNo to set
     */
    public void setContractNo(String ContractNo) {
        this.ContractNo = ContractNo;
    }
}
