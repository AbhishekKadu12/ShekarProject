/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shekhar.pojo;

/**
 *
 * @author Horten
 */
public class AddProduct {
    private String ProductName;
    private String CompanyName;
    private int ProductType;
    private String ProductCost;
    private String ProductWorranyDate;
    private int ProdcutID;

    /**
     * @return the ProductName
     */
    public String getProductName() {
        return ProductName;
    }

    /**
     * @param ProductName the ProductName to set
     */
    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    /**
     * @return the CompanyName
     */
    public String getCompanyName() {
        return CompanyName;
    }

    /**
     * @param CompanyName the CompanyName to set
     */
    public void setCompanyName(String CompanyName) {
        this.CompanyName = CompanyName;
    }

    /**
     * @return the ProductType
     */
   

    /**
     * @return the ProductCost
     */
    public String getProductCost() {
        return ProductCost;
    }

    /**
     * @param ProductCost the ProductCost to set
     */
    public void setProductCost(String ProductCost) {
        this.ProductCost = ProductCost;
    }

    /**
     * @return the ProductWorranyDate
     */
    public String getProductWorranyDate() {
        return ProductWorranyDate;
    }

    /**
     * @param ProductWorranyDate the ProductWorranyDate to set
     */
    public void setProductWorranyDate(String ProductWorranyDate) {
        this.ProductWorranyDate = ProductWorranyDate;
    }

    /**
     * @return the ProductType
     */
    public int getProductType() {
        return ProductType;
    }

    /**
     * @param ProductType the ProductType to set
     */
    public void setProductType(int ProductType) {
        this.ProductType = ProductType;
    }

    /**
     * @return the ProdcutID
     */
    public int getProdcutID() {
        return ProdcutID;
    }

    /**
     * @param ProdcutID the ProdcutID to set
     */
    public void setProdcutID(int ProdcutID) {
        this.ProdcutID = ProdcutID;
    }
    
}
